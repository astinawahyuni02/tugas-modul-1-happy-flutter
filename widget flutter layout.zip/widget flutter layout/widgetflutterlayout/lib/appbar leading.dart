import 'package:flutter/material.dart';

void main() {
  runApp( new MaterialApp(home: new Application()));
}

class Application extends StatefulWidget{
  @override
  _ApplicationState createState() => _ApplicationState();
}

class _ApplicationState extends State<Application> {
  String txt = '';

  @override
  Widget build(BuildContext context) {
    return new Scaffold(appBar: new AppBar(backgroundColor: Colors.green,
      title: new Text('AppBar Widget'),
      leading: new Icon(Icons.menu),
      actions: <Widget>[
        new IconButton(icon: new Icon(Icons.add), onPressed: () {
          txt = 'This is Arrow Button';
        }),
        new IconButton(icon: new Icon(Icons.star), onPressed: () {
          txt = 'This is Arrow Button';
        }),
      ],
    ),
    );
  }
}
