import 'package:flutter/material.dart';

void main() {
  runApp(new container());
}
class container extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: new Scaffold(
        body: new Container(
          color: Colors.black,
          child: new Text('My Container'),
          height: 500.0,
          width: 300.0,
          alignment: Alignment.center,
          padding: const EdgeInsets.all(20.0),
          foregroundDecoration: BoxDecoration(
              color: Colors.blueGrey
          ),
        ),
      ),
    );
  }

}
