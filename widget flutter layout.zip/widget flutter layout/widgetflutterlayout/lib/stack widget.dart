import 'package:flutter/material.dart';

void main() {
  runApp( new MaterialApp(home: new Application()));
}

class Application extends StatefulWidget{
  @override
  _ApplicationState createState() => _ApplicationState();
}

class _ApplicationState extends State<Application> {
  @override
  Widget build(BuildContext context) {
    return new Container(
      color: Colors.blue,
      child: Stack(
        children: <Widget>[
          Container(width: 300, height: 300, color: Colors.green[200],
          ),
          Container(width: 200, height: 200, color: Colors.yellow[200],
          ),
          Container(width: 100, height: 100, color: Colors.red[200],)
        ],
      ),
    );
  }
}

