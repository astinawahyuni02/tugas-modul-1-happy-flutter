import 'package:flutter/material.dart';

void main() {
  runApp(new Container());
}
class container extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
    return MaterialApp(
      home: new Scaffold(
        body: new Container(
          color: Colors.black,
          child: new Text('My Container'),
          height: 300.0,
          width: 300.0,
          alignment: Alignment.center,
          padding: const EdgeInsets.all(20.0),
          foregroundDecoration: BoxDecoration(
              color: Colors.lightBlue
          ),
        ),
      ),
    );
  }
}
