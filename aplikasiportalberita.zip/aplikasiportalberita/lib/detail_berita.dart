import 'package:flutter/material.dart';

// ignore: must_be_immutable
class DetailPageBerita extends StatefulWidget{
  List list;
  int index;
  DetailPageBerita({this.list, this.index});

  @override
    _DetailPageBeritaState createState()=> _DetailPageBeritaState();

}

class _DetailPageBeritaState extends State<DetailPageBerita> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(appBar: AppBar(
      title: Text('${widget.list[widget.index]['judul_berita']}'),
      backgroundColor: Colors.blue,
    ),
    body: new ListView(
      children: <Widget>[
        new Image.network("http://172.16.0.9/berita/gambar/" +widget.list[widget.index]['gbr_berita']),
        new Container(padding: const EdgeInsets.all(32.0),
        child: new Row(
          children: [
            new Expanded(child: new Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                new Container(padding: const EdgeInsets.only(bottom: 8.0),
                child: new Text('Judul: ' +widget.list[widget.index]['judul_berita'],
                style: new TextStyle(fontWeight: FontWeight.bold),),),

                new Text('Tanggal: ' +widget.list[widget.index]['tgl_berita'],
                style: new TextStyle(color: Colors.blue),)
              ],
            )),
            new Icon(Icons.star, color: Colors.blue,)
          ],
        ),),
        new Container(padding: const EdgeInsets.all(32.0),
        child: new Text(widget.list[widget.index]['isi_berita'],
        softWrap: true,),)
      ],
    ),
    );
  }
}