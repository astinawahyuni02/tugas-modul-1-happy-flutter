import 'package:flutter/material.dart';

void main() {
  runApp( new MyApp());
}

// ignore: must_be_immutable
class MyApp extends StatelessWidget{
  //  //Number
  int umur = 21;
  double y=1.1;

  //String
  String nama1="Astina";
  String nama2="Wahyuni";

  //boolean
  bool magang = true;

  //Map
  Map<String,String> alamat = Map();

  //List

  // ignore: non_constant_identifier_names
  var num_list=[2,50,90];

  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'tipe data dart',
      home: Scaffold(
        appBar: new AppBar( title: new Text('tipe data dart'),),
        body: Column(
          children: <Widget>[
            Text('$nama1 $nama2', style: TextStyle(fontSize: 20.0, ),), SizedBox(height: 10.0,),
            Text('$umur', style: TextStyle(fontSize: 20.0),), SizedBox(height: 20.0,),
            Text('$magang', style: TextStyle(fontSize: 20.0),), SizedBox(height: 25.0,),
            Text(alamat["alamat"]="Gang alpukat" ,style: TextStyle(fontSize: 20.0),), SizedBox(height: 10.0,),
            Text(alamat["kec"]="Ciputat" ,style: TextStyle(fontSize: 20.0),), SizedBox(height: 10.0,),
            Text('Angka Pertama = ${num_list.first}' ,style: TextStyle(fontSize: 20.0),), SizedBox(height: 10.0,),
            Text('Angka Terakhir = ${num_list.last}' ,style: TextStyle(fontSize: 20.0),), SizedBox(height: 10.0,),
            Text('Jumlah Angka = ${num_list.length}' ,style: TextStyle(fontSize: 20.0),), SizedBox(height: 10.0,),
            Text('Properti isEmpty = ${num_list.isEmpty}' ,style: TextStyle(fontSize: 20.0),), SizedBox(height: 10.0,),
            Text('Properti isNotEmpty = ${num_list.isNotEmpty}' ,style: TextStyle(fontSize: 20.0),), SizedBox(height: 10.0,),
          ],
        ),

      ),
    );
  }
}
