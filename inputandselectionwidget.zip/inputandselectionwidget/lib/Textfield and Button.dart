import 'package:flutter/material.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Textfield ',
    home: Home(),
    );
  }
}

class Home extends StatefulWidget{
  @override
   _HomeState createState()=> _HomeState();

}

class _HomeState extends State<Home> {
  String text='';
  String message ='';

  void showText(){
    setState(() {
      message = 'Hallo' + text + ', have a nice day!';
    });
  }

  void sendTextFieldValue(String value){
    setState(() {
      text=value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar( title: Text('Textfield'),),

    body: Container(padding: EdgeInsets.all(20.0),
    child: Column( children: <Widget>[
      TextField( decoration: InputDecoration(
        hintText: 'Type Your Text',
        hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
      ),
        onChanged: (String value){
        sendTextFieldValue(value);
        },
      ),
      RaisedButton( child: Text('Show Text'),
          onPressed: (){
        showText();
          },),
      Container(height: 100.0,),
      Text(message)
    ],),),);
  }
}

