import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}
class MyApp extends StatefulWidget{
  @override
  _appliacationState createState()=> _appliacationState();

}

class _appliacationState extends State<MyApp>{
  String txt='';

  @override
  void initState(){
    txt ='klik tombol ini';
    super.initState();
  }
  void method1(){
    setState(() {
      txt='The text is changed';
    });
  }

  @override
  Widget build(BuildContext context) {

    return new MaterialApp(
        title: 'Stateful Widget',
        home : new  Scaffold(
          body:  new Center(
            child: new RaisedButton(onPressed: ()
            {method1();}, child: new Text(txt),),
          ),
        )
    );
  }

}
