import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return  new MaterialApp(
        title: 'Stateless Widget',
        home : new  Scaffold(
          body: new Container(
            color: Colors.blue,
            child: new Container(
              color: Colors.purple,
              margin: const
              EdgeInsets.all(50.0),
            ),
          ),
        )
    );
  }
}
